package com.project.samplefooddelivery.helper

open class AppConstants {

    protected val appName: String = "safod"


}