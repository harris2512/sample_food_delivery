package com.project.samplefooddelivery.ui.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.project.samplefooddelivery.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}